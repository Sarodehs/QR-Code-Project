import React from "react";
import Sidebar from "./Sidebar";
import './navigation.css';

function Navigation() {
  return (
    <>
      <div>
        <Sidebar />
      </div>
    </>
  );
}

// const rootElement = document.getElementById("root");
// ReactDOM.render(<Navigation />, rootElement);
export default Navigation