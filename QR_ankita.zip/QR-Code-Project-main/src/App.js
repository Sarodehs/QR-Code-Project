import NavigationRoute from "./Navigation/NavigationRoute";
import Sigin from "./SignIn";
import "./App.css";

function App() {
  const isLoggedIn = true;
  if (isLoggedIn) {
    return <NavigationRoute />;
  }
  return <Sigin />;
}
export default App;
