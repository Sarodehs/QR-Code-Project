import { PaginationTable } from './OrderTable';

function Transition(){
    return(

        <div style={{margin:'20px' }}>
            <div style={{display:'flex', justifyContent:'space-between',alignItems: 'center'}}>
                <h2>Transition</h2>
                <div className='search-input'>
                    <input type="text" placeholder="Search...." />
                    {/* <img src={searchIcon} alt=':)' /> */}<span class="material-icons-outlined">
search
</span>
                    </div>
            </div>
        <PaginationTable />
        </div>

    );
}

export default Transition;