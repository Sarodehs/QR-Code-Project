import { PaginationTable } from './OrderTable';

function RequestForService(){
    return(

        <div style={{margin:'20px' }}>
        <h2>Request For Service</h2>                

            <div className='row rfs'  style={{alignItems: 'center',margin:'20px'}}>
                <section className='col' style={{display: 'flex'}}>
                    <button><span class="material-icons-outlined">file_download</span> Export to CSV</button>
                    <button><span class="material-icons-outlined">phone</span> Contact</button>
                    <button><span class="material-icons-outlined">calendar_today</span> Schedule</button> </section>
                <section className='col-4 search-input'>
                    <input type="text" placeholder="Search...." />
                    <span class="material-icons-outlined">search</span>
                </section>
            </div>

        <PaginationTable />
        </div>

    );
}

export default RequestForService;