import { PaginationTable } from './OrderTable';

function Ticket(){
    return(

        <div style={{margin:'10px' }}>
            <div className='row rfs' style={{alignItems: 'center',margin:'20px'}}>
                <h2 className='col-2'>Ticket</h2>                
                <section className='col' style={{display: 'flex'}}>
                    <button><span class="material-icons-outlined">file_download</span> <p>Export to CSV</p></button>
                    <button><span class="material-icons-outlined">delete</span> Delete</button>
                    <button><span class="material-icons-outlined">reply</span> Assign</button>
                    <button><span class="material-icons-outlined">calendar_today</span> Schedule</button>  </section>
                <section className='col-4 search-input'>
                    <input type="text" placeholder="Search...." />
                    <span class="material-icons-outlined">search</span>
                </section>
            </div>
        <PaginationTable />
        </div>

    );
}

export default Ticket;