import { PaginationTable } from './OrderTable';

function CustomerMain(){
    return(

        <div style={{margin:'20px' }}>
            <p> Dashboard | Customer | View</p>
            <div style={{display:'flex', justifyContent:'space-between',alignItems: 'center'}}>
                <h2>Customer Details</h2>
                <div style={{display:'flex'}}>
                    <div className='table-bottom'><button > + Add Cusstomer</button></div>                    
                    <div  className='search-input' style={{margin: '30px'}}>
                        <input type="text" placeholder="Search...." />
                        <span class="material-icons-outlined">search</span></div> </div>  
            </div>
        <PaginationTable />
        </div>

    );
}

function CustomerTicket(){
    return(<>
        <div style={{margin:'20px' }}>
            <p> Dashboard | Customer | View |ticket</p>
            <div >
                <h2>Ticket</h2>
                <p>Topic of concern</p>
                
                <div class="btn-group">
                    <button type="button" class="btn dropdown-toggle"  style={{background:'white'}}
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Right-aligned menu
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <button class="dropdown-item" type="button">Action</button>
                        <button class="dropdown-item" type="button">Another action</button>
                        <button class="dropdown-item" type="button">Something else here</button>
                    </div>
                </div>
                
            </div>  
        </div>  
    </>)
}


export {
    CustomerMain,
    CustomerTicket,
}