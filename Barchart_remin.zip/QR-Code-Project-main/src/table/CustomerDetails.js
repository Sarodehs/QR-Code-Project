import {CustomerDetailsCard, HotelOwner,PlanCard } from "./CustomerDetailCards";


function CustomerDetails () {
    return(
        <div style={{margin:'20px'}}>
        <p>Dashboard |  Customer | View</p>
        <h1>Customer Details</h1> 

        <div className='row'>
            <div className="col-8"> 
                <div className="person">
                <CustomerDetailsCard />     
                </div>
            </div>            
                <div className='col-4 btn-activity'>
                    <HotelOwner />
                    <PlanCard />
                </div>
        </div>

        <div className="table-bottom" style={{justifyContent: 'end'}}>
            <button> Block</button>
            <button> Unblock</button>   
        </div>
        </div>


    );
}

export default CustomerDetails;