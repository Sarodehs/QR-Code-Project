function Customer02(){
    return(<>
        <div style={{margin:'20px' }}>
            <p> Dashboard | Customer | View |ticket</p>
            <div >
                <h1>Ticket</h1>
                <p>Topic of concern</p>
                
                <div class="btn-group">
                    <button type="button" class="btn dropdown-toggle"  style={{background:'white'}}
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Right-aligned menu
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <button class="dropdown-item" type="button">Action</button>
                        <button class="dropdown-item" type="button">Another action</button>
                        <button class="dropdown-item" type="button">Something else here</button>
                    </div>
                </div>
                
            </div>  
        </div>  
    </>)
}

export default Customer02;