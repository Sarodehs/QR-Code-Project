// import { NavLink } from 'react-router-dom';
import DashboardComponent from '../Dashboard/DashboardComponent';

function Dashboard(){
    return(
        <>
        <DashboardComponent />
{/* <canvas id="myChart" style="width:100%;max-width:600px"></canvas> */}
            {/* <NavLink  to="/activities">activiti</NavLink> */}
      
        </>
    );
}

export default Dashboard;