import { PaginationTable } from './OrderTable';
import searchIcon from '../img/search.png';
function Ticket(){
    return(

        <div style={{margin:'20px' }}>
            <div style={{display:'flex', justifyContent:'space-between',alignItems: 'center'}}>
                <h1>Ticket</h1>
                
                <div className='table-bottom'>
                    <button><span> ⭳</span> Export to CSV</button>
                    <button><span> 🗑</span> Delete</button>
                    <button><span> ➦</span> Assign</button>
                    <button><span> 🗊</span> Schedule</button>  </div>
                <div className='search-input'>
                    <input type="text" placeholder="Search...." />
                    <img src={searchIcon} alt=':)' />
                </div>
            </div>
        <PaginationTable />
        </div>

    );
}

export default Ticket;