import { PaginationTable } from './OrderTable';

function Transition(){
    return(

        <>
        <div>
        <PaginationTable />
        </div>
        </>

    );
}

export default Transition;