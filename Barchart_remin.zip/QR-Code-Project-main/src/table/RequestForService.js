import { PaginationTable } from './OrderTable';
import searchIcon from '../img/search.png';

function RequestForService(){
    return(

        <div style={{margin:'20px' }}>
            <div style={{display:'flex', justifyContent:'space-between',alignItems: 'center'}}>
                <h1>Requuest For Service</h1>
                
                <div className='table-bottom'>
                    <button><span> ⭳</span> Export to CSV</button>
                    <button><span> 🖇</span> Contact</button>
                    <button><span> 🗊</span> Schedule</button>  </div>
                <div className='search-input'>
                    <input type="text" placeholder="Search...." />
                    <img src={searchIcon} alt=':)' />
                </div>
            </div>
        <PaginationTable />
        </div>

    );
}

export default RequestForService;