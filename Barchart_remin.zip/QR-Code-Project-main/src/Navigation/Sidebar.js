import React from "react";
import classnames from "classnames";
import Header from "./Header";
import { NavLink,Link,   Outlet } from 'react-router-dom';

import "bootstrap/dist/css/bootstrap.min.css";

class Sidebar extends React.Component {
  state = {
    open: window.matchMedia("(min-width: 1024px)").matches || false
  };

  ontoggleNav = () => {
    this.setState(prevState => ({
      open: !prevState.open
    }));
  };

  render() {
    const { open } = this.state;
    const mobile = window.matchMedia("(max-width: 768px)").matches;
    console.log(mobile, open);
    return (
      <div>
        <div className="navHeaderWrap">
          <Header ontoggleNav={this.ontoggleNav} />
        </div>
        <div className="bodyWrap">
          <div className={classnames({ blur: mobile && open })} />
          <div
            className={classnames(
              "sidenav",
              { sidenavOpen: open },
              { sidenavClose: !open }
            )}
          >
            <a
              href="javascript:void(0)"
              className="closebtn hidex"
              onClick={() => this.ontoggleNav("0px")}
            >
              &times;
            </a>  
       
            <Link to="/">Dashboard</Link>         
            <Link to="/transition">Transition</Link>
            <Link to="/customer">Customer</Link>          
            <Link to="/ticket">Ticket</Link>
      
          </div>

          <div
            className={classnames(
              "main",
              { mainShrink: open },
              { mainExpand: !open },
              { noscroll: mobile && open }
            )}
          >
            {/* <h2> Push this Div inside</h2> */}
            <Outlet />
          </div>
        </div>
      </div>
    );
  }
}



function ProfileSetting(){
  return(
    <>
             
      <div class="btn-group">
      <button type="button" class="btn dropdown-toggle"  style={{background:'white'}}
        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Jayesh Sarode
      </button>
      <div class="dropdown-menu dropdown-menu-right">
        <span> Jayesh Sarode</span>
        <span>ab.cd@gmail.com</span> 
        <button class="dropdown-item" type="button">Profile</button>
        <button class="dropdown-item" type="button">Setting</button>
        <button class="dropdown-item" type="button">Help</button>
        <button class="dropdown-item" type="button">Logout</button>
      </div>
    </div>
    </>
  )
}

// export default Sidebar;

export {
  Sidebar,
  ProfileSetting,

}
