import Ip from "./components/Ip";
import "./Component.css";

function DashboardComponent() {
  return (
    <>
      <Ip />
    </>
  );
}
export default DashboardComponent;
