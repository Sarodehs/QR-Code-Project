function IpTbl1() {
  return (
    <>
      <div className="request-tbl">
        <h3>Request for Service</h3>
        <table>
          <tr>
            <th>Date</th>
            <th>Name</th>
            <th>Message</th>
          </tr>
          <tr>
            <td>06/14/1969</td>
            <td>Maria Anders</td>
            <td>Premium credentials are not recived</td>
          </tr>
          <tr>
            <td>04/22/1978</td>
            <td>Dorthy Willson</td>
            <td>Premium credentials are not recived</td>
          </tr>
          <tr>
            <td>01/20/1999</td>
            <td>Mony Cook</td>
            <td>Premium credentials are not recived</td>
          </tr>
          <tr>
            <td>05/19/2001</td>
            <td>Jenery Weber</td>
            <td>Premium credentials are not recived</td>
          </tr>
        </table>
      </div>
    </>
  );
}

export default IpTbl1;
