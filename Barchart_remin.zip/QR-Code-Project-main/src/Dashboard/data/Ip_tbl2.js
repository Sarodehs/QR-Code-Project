function IpTbl2() {
  return (
    <>
      <div className="row">
        <div className="col-8 ">
          <div className="line-graph">
            <h3>Recent Orders</h3>
            <table>
              <tr>
                <th>Date</th>
                <th>Customer Name</th>
                <th>Hotel Name</th>
                <th>Plan Status</th>
                <th>Plan</th>
                <th>City</th>
              </tr>
              <tr>
                <td>17/07/2008</td>
                <td>Amer Pandey</td>
                <td>Vulputate mattis rhoncus</td>
                <td>Activated</td>
                <td>Free</td>
                <td>Pune</td>
              </tr>
              <tr>
                <td>17/07/2008</td>
                <td>Amer Pandey</td>
                <td>Vulputate ipsum</td>
                <td>Not Activated</td>
                <td>Free</td>
                <td>Mumbai</td>
              </tr>
              <tr>
                <td>17/07/2008</td>
                <td>Amer Pandey</td>
                <td>Prasent nisl</td>
                <td>Activated</td>
                <td>Gold</td>
                <td>Banglore</td>
              </tr>
              <tr>
                <td>17/07/2008</td>
                <td>Amer Pandey</td>
                <td>Prasent nisl</td>
                <td>Activated</td>
                <td>Gold</td>
                <td>Banglore</td>
              </tr>
            </table>
          </div>
        </div>
        <div className="col-4 ">
          <div className="activities">
            <h3>Acquire Cities</h3>
            <div className="row ">
              <div className="col">Pune</div>
              <div className="col text-right">55</div>
            </div>
            <div className="row">
              <div className="col">Lima</div>
              <div className="col">
                <div className="float-right">287</div>
              </div>
            </div>
            <div className="row">
              <div className="col">Lima</div>
              <div className="col">
                <div className="float-right">287</div>
              </div>
            </div>
            <div className="row">
              <div className="col">Prague</div>
              <div className="col">
                <div className="float-right">1210</div>
              </div>
            </div>
            <div className="row">
              <div className="col">Kuala Lumpur</div>
              <div className="col">
                <div className="float-right">1130</div>
              </div>
            </div>
            <div className="row">
              <div className="col">Berlin</div>
              <div className="col">
                <div className="float-right">924</div>
              </div>
            </div>
            <div className="row">
              <div className="col">Las Vegas</div>
              <div className="col">
                <div className="float-right">341</div>
              </div>
            </div>
            <div className="row">
              <div className="col">Lisbon</div>
              <div className="col">
                <div className="float-right">490</div>
              </div>
            </div>
            <div className="row">
              <div className="col">Vancouer</div>
              <div className="col">
                <div className="float-right">568</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default IpTbl2;
