import img1 from "../img/iptotalMemberIcon.png";
import img2 from "../img/ipgoldIcon.png";
import img3 from "../img/ipSilverIcon.png";
import img4 from "../img/ipFreeIcon.png";

function MemberCount() {
  return (
    <>
      <div className="container-member-count">
        <div style={{ backgroundColor: "#FFF5EA" }}>
          <img src={img1} alt="group icon" />
          <main>
            <span>Total Members</span>
            <br />
            <p>200</p>
          </main>
        </div>
        <div className="gold">
          <img src={img2} alt="group icon" />
          <main>
            <span>Gold</span>
            <br />
            <p>075</p>
          </main>
        </div>
        <div className="sliver">
          <img src={img3} alt="group icon" />
          <main>
            <span>Sliver</span>
            <br />
            <p>100</p>
          </main>
        </div>
        <div className="free">
          <img src={img4} alt="group icon" />
          <main>
            <span>Free</span>
            <br />
            <p>025</p>
          </main>
        </div>
      </div>
    </>
  );
}

export default MemberCount;
