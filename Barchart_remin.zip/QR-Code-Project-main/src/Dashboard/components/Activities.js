function Activities() {
  return (
    <div className="activities">
      <h3>Activities</h3>
      <div className="container">
        <div className="step ">
          <div className="v-stepper">
            <div className="circle"></div>
            <div className="line"></div>
          </div>
          <div className="content">
            <p>Enquiry For Basic Plan</p>
            <span>10:30Jan</span>
          </div>
        </div>
        <div className="step ">
          <div className="v-stepper">
            <div className="circle"></div>
            <div className="line"></div>
          </div>
          <div className="content">
            <p>Issue in Updating Order</p>
            <span>10:30Jan</span>
          </div>
        </div>
        <div className="step ">
          <div className="v-stepper">
            <div className="circle"></div>
            <div className="line"></div>
          </div>
          <div className="content">
            <p>Amanda and team update menu</p>
            <span>10:30Jan</span>
          </div>
        </div>
        {/* <div className="step ">
          <div className="v-stepper">
            <div className="circle"></div>
            <div className="line"></div>
          </div>
          <div className="content">
            <p>Ravi raised Ticket</p>
            <span>10:30Jan</span>
          </div>
        </div> */}
        <div className="step">
          <div className="v-stepper">
            <div className="circle"></div>
            <div className="line"></div>
          </div>

          <div className="content">
            <p>Anand's ticket is resolved</p>
            <span>10:30Jan</span>
          </div>
        </div>

        <a href="https://www.facebook.com/login/">See All</a>
      </div>
    </div>
  );
}

export default Activities;
