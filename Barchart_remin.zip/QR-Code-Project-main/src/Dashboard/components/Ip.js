import MemberCount from "./MemberCount";
import Linegraph from "../data/LineGraph";
import Activities from "./Activities";
// import BarGraph from "../data/BarChart";
import IpTbl1 from "../data/Ip_tbl1";
import PieChartSample from "../data/PieChart";
import IpTbl2 from "../data/Ip_tbl2";

function Ip() {
  return (
    <div style={{ margin: "5px 30px" }}>
      <MemberCount />
      <div className="row">
        <div className="col-8">
          <Linegraph />
        </div>
        <div className="col-4 ">
          <Activities />
        </div>
      </div>

      <div class="row">
        <div class="col">
          {/* <BarGraph /> */} BARGRAPH
        </div>
        <div class="col-6">
          {" "}
          <IpTbl1 />
        </div>
        <div class="col">
          <PieChartSample />
        </div>
      </div>

      <IpTbl2 />

      {/* <div className="row">
        <div className="col-8">
          <IpTbl2 />
        </div>
        <div className="col-4 ">
          <Activities />
        </div>
      </div> */}
    </div>
  );
}

export default Ip;
