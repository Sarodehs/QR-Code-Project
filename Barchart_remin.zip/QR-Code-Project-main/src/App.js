
import { BrowserRouter, Routes, Route } from "react-router-dom";import Activities from './table/Activities';
import { Sidebar } from './Navigation/Sidebar';
import Dashboard from './table/Dashboard(IP)';
import Transition from './table/Transition';
import Ticket from './table/Ticket';
import Customer from './table/Customer01';
// import Customer02 from './table/Customer02';
import './App.css'


export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Sidebar />}>
          <Route index element={<Dashboard />} />
           <Route path="transition" element={<Transition />}  ></Route>
          <Route path="customer" element={<Customer />} />
          <Route path="ticket" element={<Ticket />} />
          <Route path="activities" element={<Activities />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

