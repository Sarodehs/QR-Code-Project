import Settingnav from './after_login_component/Setting_Navigation';
import './App.css';

function App() {
  return (
    <div className="">  <Settingnav/>    </div>
  );
}

export default App;
