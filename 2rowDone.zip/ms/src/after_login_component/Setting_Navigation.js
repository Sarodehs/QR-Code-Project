import React, { useState } from "react";
import {  ProSidebar,  Menu,  MenuItem,  SidebarHeader,  SidebarFooter,  SidebarContent,} from "react-pro-sidebar";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { FaList, FaRegHeart } from "react-icons/fa";
import { FiHome, FiLogOut, FiArrowLeftCircle, FiArrowRightCircle } from "react-icons/fi";
import { RiPencilLine } from "react-icons/ri";
import { BiCog } from "react-icons/bi";
import "react-pro-sidebar/dist/css/styles.css";
import Avatar from "@material-ui/core/Avatar";
import logo from '../img/logo.svg'
import { Outlet, Link } from "react-router-dom";
import TextSetting from './UI_Setting/Text_Setting';
import ThemeSetting from './UI_Setting/Theme_Setting' ;
import WallpaperSettig from './UI_Setting/Wallpaper_setting'
import MenuSetting from './UI_Setting/Menu_Setting';


const Header = () => {
    const [menuCollapse, setMenuCollapse] = useState(false)
    const menuIconClick = () => {menuCollapse ? setMenuCollapse(false) : setMenuCollapse(true);  };

  return (
    <>
      <BrowserRouter>
    
        <nav className="navbar navbar-light bg-light border-bottom">
        <a className="navbar-brand d-flex" href="#">
            <img src={logo} width="100%0" alt="logo" /> &nbsp;
            <SidebarHeader style={{margin:'auto 10px'}}>
            <div  onClick={menuIconClick}>
              {menuCollapse ? (
                <FiArrowRightCircle/>
              ) : (
                <FiArrowLeftCircle/>
              )}
            </div>
          </SidebarHeader>
        </a>
            <div className=" my-2 my-lg-0 d-flex signup2 "  >
              <button style={{maxWidth:'100px', margin:'5px'}}>NEXT  ➔</button>
            <Avatar style={{margin:'5px'}} alt="avatar" src='' placeholder="PP" />
            </div>
        </nav>

        {/* Actual Sidebar reciding here */}
      <div id="header">
          {/* collapsed props to change menu size using menucollapse state */}
        <ProSidebar collapsed={menuCollapse}>
         
          <SidebarContent>
            <Menu iconShape="square">
            {/* <MenuItem active={true}><span className="material-icons-outlined">palette</span> &nbsp; Theme <Link to='/' />  </MenuItem> */}
            <MenuItem ><span className="material-icons-outlined">palette</span> &nbsp; Theme <Link to='/' />  </MenuItem>
              <MenuItem > <span className="material-icons-outlined">title</span>&nbsp; Text <Link to='/text' />  </MenuItem>
              <MenuItem ><span className="material-icons-outlined">wallpaper</span>&nbsp; Wallpaper <Link to='/wallpaper' />  </MenuItem>
              <MenuItem > <span className="material-icons-outlined">restaurant_menu</span>&nbsp; Menu <Link to='/menu' />  </MenuItem>
            </Menu>
          </SidebarContent>
            <Outlet />
        </ProSidebar>

      </div>

      {/* Routing path is given here */}
      <Routes>
        <Route path='/' element={<ThemeSetting />} />
        <Route path="text" element={<TextSetting />} />
        <Route path="wallpaper" element={<WallpaperSettig />} />
        <Route path="menu" element={<MenuSetting />} />
      </Routes>
      </BrowserRouter>

      {/* Pages for interation will be available in below div */}
 
    </>
  );
};

export default Header;
