import Layout from './Setting_Navigation'
import FontSetting from './UI_Setting/Font_Setting'
import ThemeSetting from './UI_Setting/Theme_Setting';


export default function NavigationRoute() {
    return (
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<SettingNavigation />}>
            <Route index element={<FontSetting />} />
            <Route path="blogs" element={<ThemeSetting />} />
            <Route path="contact" element={<FontSetting />} />
            <Route path="*" element={<FontSetting />} />
          </Route>
        </Routes>
      </BrowserRouter>
    );
  }