import img1 from '../themeScreen/theme1-screen1.png'
import img2 from '../themeScreen/theme1-screen2.png'
import img3 from '../themeScreen/theme1-screen3.png'

function ThemeSetting(){
    return(<>
    <div className="setting-margin">
    <div className="row text-center">
        <div className="col-3">
           <h2>Select Theme</h2> 
            {/* theme 1 */}
           <div className="border border-danger rounded p-2 m-2">
               Alfa Pack
                <div class='row' style={{margin:'10px',border:'1px solid gray'}}>
                <div class='col' style={{background:'#3B4D91',height:'50px'}}></div>
                <div class='col' style={{background:'#2F1710',height:'50px'}}></div>
                <div class='col' style={{background:'#B9B5B5',height:'50px'}}></div>
                <div class='col' style={{background:'#FFFFFF',height:'50px'}}></div>
                </div>
                <span >Recommended</span>
           </div>
            {/* theme 2 */}
           <div className="border border-dark rounded p-2 m-2">
               Alfa Pack
                <div class='row' style={{margin:'10px',border:'1px solid gray'}}>
                <div class='col' style={{background:'#F9B515',height:'50px'}}></div>
                <div class='col' style={{background:'#1A1717',height:'50px'}}></div>
                <div class='col' style={{background:'#B9B5B5',height:'50px'}}></div>
                <div class='col' style={{background:'#FEF3D9',height:'50px'}}></div>
                </div>
           </div>
            {/* theme 3 */}
           <div className="border border-dark rounded p-2 m-2">
               Alfa Pack
                <div class='row' style={{margin:'10px',border:'1px solid gray'}}>
                <div class='col' style={{background:'#373D20',height:'50px'}}></div>
                <div class='col' style={{background:'#A8CE3E',height:'50px'}}></div>
                <div class='col' style={{background:'#B9B5B5',height:'50px'}}></div>
                <div class='col' style={{background:'#FFFFFF',height:'50px'}}></div>
                </div>
           </div>
            {/* theme 4 */}
           <div className="border border-dark rounded p-2 m-2">
               Alfa Pack
                <div class='row' style={{margin:'10px',border:'1px solid gray'}}>
                <div class='col' style={{background:'#FC7700 ',height:'50px'}}></div>
                <div class='col' style={{background:'#2F1710',height:'50px'}}></div>
                <div class='col' style={{background:'#B5B1B1',height:'50px'}}></div>
                <div class='col' style={{background:'#FFFFFF',height:'50px'}}></div>
                </div>
           </div>
        </div>

        <div className="col-9 text-centern ">
        <h2>Preview</h2>
        <div className=' justify-content-between'>
            <img src={img1} alt='' className='theme-screen-demo'/>
            <img src={img2} alt='' className='theme-screen-demo'/>
            <img src={img3} alt=''  className='theme-screen-demo' />
            </div>
        </div>
    </div>
    </div>
    </>);
}
export default ThemeSetting;