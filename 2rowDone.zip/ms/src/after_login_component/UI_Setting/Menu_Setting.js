import { useState } from "react";
import Modal from './AddCategoryPopup';


function MenuSetting(){
    
  const [selectedImage, setSelectedImage] = useState();
  const [show, setShow] = useState(false);

  // This function will be triggered when the file field change
  const imageChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedImage(e.target.files[0]);
    }
  };

  // This function will be triggered when the "Remove This Image" button is clicked
  const removeSelectedImage = () => {
    setSelectedImage();
  };

    return(<>
    <div className="setting-margin">
        <div className="row text-center">
            <div className="col-2">
                <div className='menue-list-item' style={{border:'1px solid gray',borderStyle: 'dashed'}}>
                <button className="show-modal-btn" onClick={() => setShow(true)}>+Add Catagory</button>
                <Modal title="My Modal" onClose={() => setShow(false)} show={show}>
                    <p>This is modal body</p>
                </Modal>
                </div>

                <div className='menue-list-item border border-danger'>
                    <img src='https://www.seekpng.com/png/detail/737-7378344_starters.png' alt='' />
                    <span>Starters</span>
                </div>

                <div className='menue-list-item border'>
                    <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSiwWFp0wQHuL4xHh0-9Oqj5zHbpWZoSELI_Q&usqp=CAU' alt='' />
                    <span>Curries</span>
                </div>

                <div className='menue-list-item border'>
                    <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBOaJhTD2FSckLzBQ22CME-wSFa5E0XjEqgg&usqp=CAU' alt='' />
                    <span>Soups</span>
                </div>

                <div className='menue-list-item border '>
                    <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2Lrp15N6pM1LT99IMmScXTEhtvx2A-w3aCQ&usqp=CAU' alt='' />
                    <span>Fries</span>
                </div>

                <div className='menue-list-item border'>
                    <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2eMeRQptbsMLF3bWZWbLEI5bseDL-K257yw&usqp=CAU' alt='' />
                    <span>Rice/ Biriyani</span>
                </div>

                <div className='menue-list-item border'>
                    <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3IHPafb8_z8T9sW_e5J2QiuUKm11QMmsrOA&usqp=CAU' alt='' />
                    <span>Dessert</span>
                </div>

                <div className='menue-list-item border'>
                    <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSK00hKX38KW_Y_xKTcW5xyZF-NvwIweAhUQw&usqp=CAU' alt='' />
                    <span>Shakes</span>
                </div>

            </div>

            <div className="col-10 ">
                <h2>Add Dish</h2><br/>
                <div className="row add-dish-pane"> 
                    <div className="col">
                    {!selectedImage && (
                        <div >
                        <input type='file'
                        accept="image/*"  className="dish-priview-btn"  
                        onChange={imageChange}
                        />  <br/> Drag-drop or <br/>click above to upload image
                        </div>
                    )}
                    {selectedImage && (
                        <div >
                        <img src={URL.createObjectURL(selectedImage)} width='200px' height='200px' alt="Thumb" /> <br /> <br/> 
                        <button className="uplosdimg" onClick={removeSelectedImage} > Remove Image </button>
                        </div>
                    )}<br/>
        
                    </div>
                    <div className="col signup2">
                        <input className="m-2" style={{border: 'inset'}} type='text' placeholder="Name Of Food.."/>
                        <textarea type='text' style={{border: 'inset'}} placeholder="Write Ingredient .." />
                    </div>

                    <div className="col">
                        
                    <div class="dropdown">
                    <button class="btn dropdown-toggle m-2" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Type
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Curry</a>
                            <a class="dropdown-item" href="#">Rice</a>
                            <a class="dropdown-item" href="#">Juce</a>
                        </div>
                    </div>
                    <div class="dropdown">
                    <button class="btn dropdown-toggle m-2" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Test
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Sweet</a>
                            <a class="dropdown-item" href="#">Sour</a>
                            <a class="dropdown-item" href="#">Spicy</a>
                        </div>
                    </div>
                    
                    <div class="dropdown">
                    <button class="btn dropdown-toggle m-2" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Best Seller
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Sweet</a>
                            <a class="dropdown-item" href="#">Sour</a>
                            <a class="dropdown-item" href="#">Spicy</a>
                        </div>
                    </div>
                    <div className="signup2" >
                        <input type='text' style={{width:'200px',border: 'inset'}} placeholder="Price" />
                    </div> 
                    </div>
                </div>
               
                <div className="signup2" >
                        <button>+ Add Catagory</button>
                </div> 

            </div>
        </div>        
    </div>
    </>);
}
export default MenuSetting;  