import img1 from '../themeScreen/theme1-screen1.png'
import img2 from '../themeScreen/theme1-screen2.png'
import img3 from '../themeScreen/theme1-screen3.png'

function TextSetting(){
    return(<>
    <div className="setting-margin">
    <div className="row text-center">
        <div className="col-3">
           <h2>Select Font</h2> <br/>
           
           <p>Title</p>
           <div class="dropdown">
                <button class="btn dropdown-toggle border border-danger" type="button" id="dropdownMenuButton" 
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"  style={{ width: '-webkit-fill-available',background:'white'}}>
                   Nano Serif
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="#">Noto Serif</a>
                    <a class="dropdown-item" href="#">San Serif</a>
                    <a class="dropdown-item" href="#"> here</a>
                </div>
            </div><br/>

            <p>Sub Title</p>
            <div class="dropdown">
                <button class="btn dropdown-toggle border border-danger" type="button" id="dropdownMenuButton" 
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"  style={{ width: '-webkit-fill-available',background:'white'}}>
                   Nano Serif
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="#">Noto Serif</a>
                    <a class="dropdown-item" href="#">San Serif</a>
                    <a class="dropdown-item" href="#"> here</a>
                </div>
            </div>

        </div>

        <div className="col-9 text-centern ">
        <h2>Preview</h2>
        <div className=' justify-content-between'>
            <img src={img1} alt='' className='theme-screen-demo'/>
            <img src={img2} alt='' className='theme-screen-demo'/>
            <img src={img3} alt=''  className='theme-screen-demo' />
            </div>
        </div>
    </div>
    </div>
    </>);
}
export default TextSetting;