import demologo  from "../themeScreen/demoLogo.png";
import wall1 from '../themeScreen/wall1.png'

function WallpaperSetting(){
    return(<>
    <div className="setting-margin">
        <div className="row text-center">
            <div className="col-3">
            <h2>Select Theme</h2> 
                    <div className='wallpaper1 border border-danger'></div>
                    {/* <span >Recommended</span> */}                
                    <div className='wallpaper2 '></div>
                    <div className='wallpaper3 '></div>
                    <div className='wallpaper4 border rounded-pill px-md-5 '>
                    <span class="material-icons-outlined p-2">file_upload</span><br/>Upload and Use</div>
                    </div>

            <div className="col-9  ">
                <h2>Preview</h2><br/>
                    <div className='d-flex justify-content-center'>
                    <div class="card" style={{width: '18rem',borderRadius:'20px'}} >
                        <img alt="logo" className="m-auto" style={{width: '-webkit-fill-available',borderRadius:'20px'}} src={demologo} />
                        <span style={{background:'#3B4D91',color:'white',width :'100px',margin:'0 auto'}}> Menue </span>
                        <img alt='logo'  className="m-auto"  style={{width: '-webkit-fill-available',borderRadius:'20px'}} src={wall1} />
                    </div>
                </div>
                <h6>Main Screen</h6>
            </div>
        </div>        
    </div>
    </>);
}
export default WallpaperSetting;