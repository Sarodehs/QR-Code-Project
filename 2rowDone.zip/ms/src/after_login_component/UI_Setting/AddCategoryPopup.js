import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom";
import { CSSTransition } from "react-transition-group";
import "../../App.css";

const Modal = (props) => {
  const [selectedImage, setSelectedImage] = useState();

  // This function will be triggered when the file field change
  const imageChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedImage(e.target.files[0]);
    }
  };

  // This function will be triggered when the "Remove This Image" button is clicked
  const removeSelectedImage = () => {
    setSelectedImage();
  };

  const closeOnEscapeKeyDown = (e) => {
    if ((e.charCode || e.keyCode) === 27) {
      props.onClose();
    }
  };

  useEffect(() => {
    document.body.addEventListener("keydown", closeOnEscapeKeyDown);
    return function cleanup() {
      document.body.removeEventListener("keydown", closeOnEscapeKeyDown);
    };
  }, []);

  return ReactDOM.createPortal(
    <CSSTransition
      in={props.show}
      unmountOnExit
      timeout={{ enter: 0, exit: 300 }}
    >
      <div className="modal" onClick={props.onClose}>
        <div className="modal-content" onClick={(e) => e.stopPropagation()}>
          <div className="modal-header ">
            <h4 className="modal-title font-weight-bold">Add Category</h4>
            <button onClick={props.onClose} className="button float-right">
              X
            </button>
          </div>
          <div className="modal-body">
            <div className="row add-dish-pane text-center">
              <div className="col">
                {!selectedImage && (
                  <div>
                      Catagory Icon<br/>
                    <input
                      type="file"
                      accept="image/*"
                      className="dish-priview-btn"
                      onChange={imageChange}
                    />{" "}
                    <br /> Drag-drop or <br />
                    click above to upload image
                  </div>
                )}
                {selectedImage && (
                  <div>
                    <img
                      src={URL.createObjectURL(selectedImage)}
                      width="100px"
                      height="100px"
                      alt="Thumb"
                    />{" "}
                    <br /> <br />
                    <button className="uplosdimg" onClick={removeSelectedImage}>
                      {" "}
                      Remove Image{" "}
                    </button>
                  </div>
                )}
                <br />
              </div>
              <div className="col signup2">
                <input
                  className="m-2"
                  style={{ border: "inset" }}
                  type="text"
                  placeholder="Name Of Food.."
                />
                <textarea
                  type="text"
                  style={{ border: "inset" }}
                  placeholder="Write Ingredient .."
                />
                <br/>
                <button>Add Category</button>
              </div>
            </div>
          </div>
          <div className="modal-footer"></div>
        </div>
      </div>
    </CSSTransition>,
    document.getElementById("root")
  );
};

export default Modal;
