import signupimg from '../img/signup.png';
import logo from '../img/logo.svg'

function Signup(){
    return(
        <>
        <div className="row signup">
            <div className="col signup1">
                <img  src={signupimg} alt="MOTO"/>
                <h4>Modern.<br />  
&emsp;  &emsp;  &emsp;  &emsp;  &emsp;  &emsp; Accessible..<br /> 
&emsp;  &emsp;  &emsp;  &emsp;  &emsp;  &emsp; &emsp;  &emsp;  &emsp;  &emsp;  &emsp;  &emsp;  &emsp; Affordable...</h4>
               
            </div>
            <div className="col signup2">
                <img  src={logo} alt="LOGO"/>
                <h2>Sign up to your account</h2> <br />
                <input type="text" placeholder='Email/Mobile' /> <br /><br />
                <input type="password" placeholder='Password' /> <br />
                <span style={{    marginLeft: '100px',color:'orange'}}>Forgot Password?</span><br /><br />
                <button>SIGN UP</button>
            </div>
        </div>
        
        
        </>
    )
}

export default Signup;

