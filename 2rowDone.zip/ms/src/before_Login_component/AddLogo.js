
import { useState } from "react";

const AddLogo = () => {

  const [selectedImage, setSelectedImage] = useState();

  // This function will be triggered when the file field change
  const imageChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedImage(e.target.files[0]);
    }
  };

  // This function will be triggered when the "Remove This Image" button is clicked
  const removeSelectedImage = () => {
    setSelectedImage();
  };

  return (
    <>
    
      <div className="row details" style={{padding:'20px'}}>
      <div className="col">          
        <h2>Add Restaurant Logo</h2>
        <p>Its very easy</p>      <br/>
      {!selectedImage && (
        <div >
        <input type='file'
        accept="image/*"  className="uploadbtn"  
        onChange={imageChange}
      />   
        </div>
      )}
      {selectedImage && (
        <div >
          <img src={URL.createObjectURL(selectedImage)} width='300px' height='300px' alt="Thumb" />  
        </div>
      )}

      </div>
      <div className="col signup2" >

      {selectedImage && ( 
          <button onClick={removeSelectedImage}    >
            Remove This Image
          </button>  
      )}

      <button>UPLOAD</button>
      <p>  or  
          <br />
          <a href="">Continue without logo</a>
      </p>
      </div>
      </div>
    </>
  );
};

export default AddLogo;




