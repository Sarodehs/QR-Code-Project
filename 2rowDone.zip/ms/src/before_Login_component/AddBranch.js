import addbranchImg from '../img/addbranch.png';
import logo from '../img/logo.svg'

function AddBranch(){
    return(<>
    
    <div className="row details" style={{background:'#131522'}}>
            <div className="col signup1">
                <img  src={addbranchImg} alt="MOTO"/>
                <h3>Organize your work<br />at one place</h3>
            </div>
            <div className="col signup2">
                <img  src={logo} alt="LOGO"/>
                <div className='d-flex justify-content-between m-5'>
                    <h4>Add Branch</h4><p style={{color:'red'}}>Add More</p>
                </div>

                <div className='d-flex justify-content-between m-5'>                    
                    <input type="text" style={{padding:0}} placeholder='Owner Name' /> <br />  
                    <div class="dropdown">
                    <button class="btn dropdown-toggle m-2" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        City
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Mumbai</a>
                            <a class="dropdown-item" href="#">Puna</a>
                            <a class="dropdown-item" href="#">Nashik</a>
                        </div>
                    </div>
                </div>

                <div className='d-flex justify-content-between m-5'>                    
                    <input type="text" style={{padding:0}} placeholder='Owner Name' /> <br />  
                    <div class="dropdown">
                    <button class="btn dropdown-toggle m-2" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        City
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Mumbai</a>
                            <a class="dropdown-item" href="#">Puna</a>
                            <a class="dropdown-item" href="#">Nashik</a>
                        </div>
                    </div>
                </div>

                <div className='d-flex justify-content-between m-5'>                    
                    <input type="text" style={{padding:0}} placeholder='Owner Name' /> <br />  
                    <div class="dropdown">
                    <button class="btn dropdown-toggle m-2" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        City
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Mumbai</a>
                            <a class="dropdown-item" href="#">Puna</a>
                            <a class="dropdown-item" href="#">Nashik</a>
                        </div>
                    </div>
                </div>       

                <button className='m-10'>SAVE & NEXT</button>         
            </div>
            

        </div>
    
    </>)
}

export default AddBranch;