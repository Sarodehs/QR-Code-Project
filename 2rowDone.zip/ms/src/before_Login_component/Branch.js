import branchImg from '../img/branch.png';
import logo from '../img/logo.svg'

function Branch(){
    return(<>
    
    <div className="row signup" style={{background:'#131522'}}>
            <div className="col signup1">
                <img  src={branchImg} alt="MOTO"/>
            </div>
            <div className="col signup2">
                <img  src={logo} alt="LOGO"/>
                <h2>Do you have<br/> multiple branches?</h2> <br />
                <div  className='d-flex justify-content-center '>
                <button style={{width:'130px',margin:'5px'}}>YES</button>
                <button style={{width:'130px',margin:'5px'}}>NO</button>
                </div>
            </div>
        </div>
    
    </>)
}

export default Branch;