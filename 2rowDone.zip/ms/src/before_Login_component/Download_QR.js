
import Avatar from "@material-ui/core/Avatar";
import downloading from '../img/downloadQR.png';
// import qrdemo from '../img/qrdemo.png';
import logo from '../img/logo.svg'

function DownloadQR(){
    return(<>
        <nav className="navbar navbar-light bg-light border-bottom">
        <a className="navbar-brand" href="#">
            <img src={logo} width="100%0" alt="logo" />
        </a>
            <Avatar className=" my-2 my-lg-0" alt="avatar" src='' placeholder="PP" />
        </nav>
            <div className="card text-center signup2" style={{width: "25rem", margin:'10px auto',boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px'}}>
                <h5>QR Stand Preview</h5>
                <img className="card-img-top " src={downloading} alt="Card image cap" />
                <button style={{margin:'5px auto'}}>DOWNLOAD NOW</button><br/>
                URL - <a href='https/www.restaurantname.com' >https/www.restaurantname.com</a>
                <br/>
            </div>
            
    </>)
}

export default DownloadQR;