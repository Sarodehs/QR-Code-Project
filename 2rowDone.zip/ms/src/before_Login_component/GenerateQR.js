
import Avatar from "@material-ui/core/Avatar";
import qrImg from '../img/generateQR.png';
import qrdemo from '../img/qrdemo.png';
import logo from '../img/logo.svg'

function GenerateQR(){
    return(<>
        <nav class="navbar navbar-light bg-light border-bottom">
        <a class="navbar-brand" href="#">
            <img src={logo} width="100%0" alt="logo" />
        </a>
            <Avatar className=" my-2 my-lg-0" alt="avatar" src='' placeholder="PP" />
        </nav>
        <div className="row signup" style={{background:'white'}}>
            <div className="col ">
                <img  src={qrImg} style={{borderRadius:'10px'}} alt="QR_REF" width='100%' />
            </div>
            <div className="col signup2">                
                <img  src={qrdemo} alt="RQ_DEMO" width="50%" />
                <button>Generate qr code</button>
            </div>
        </div>
    
    </>)
}

export default GenerateQR;