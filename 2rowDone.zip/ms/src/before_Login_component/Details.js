import detailimg from '../img/details.png';
import logo from '../img/logo.svg'

function Details(){
    return(
        <>
        <div className="row details">
            <div className="col signup1">
                <img  src={detailimg} alt="MOTO"/>
                <h3> Simplify the way<br /> you work!</h3>
               
            </div>
            <div className="col signup2">
                <img  src={logo} alt="LOGO"/>
                <h2>Sign up to your account</h2> <br />
                <input type="text" placeholder='Owner Name' /> <br />
                <input type="text" placeholder='Restaurant Name' /> <br />
                <input type="text" placeholder='Hotel Address Line 01' /> <br />
                <input type="text" placeholder='Hotel Address Line 01' /> <br />
                <div className='d-flex justify-content-center'>
                    <div class="dropdown">
                    <button class="btn dropdown-toggle m-2" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        City
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Mumbai</a>
                            <a class="dropdown-item" href="#">Puna</a>
                            <a class="dropdown-item" href="#">Nashik</a>
                        </div>
                    </div>
                    <div class="dropdown">
                    <button class="btn dropdown-toggle m-2" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        State
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Maharashtra</a>
                            <a class="dropdown-item" href="#">Delhi</a>
                            <a class="dropdown-item" href="#">MP</a>
                        </div>
                    </div>
                </div>
                <br/>
             <button>SAVE & NEXT</button>
            </div>
        </div>        
        </>
    )
}

export default Details;

