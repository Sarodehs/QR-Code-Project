import React from "react";
import classnames from "classnames";
import Header from "./Header";
import { NavLink,Link,   Outlet } from 'react-router-dom';

import "bootstrap/dist/css/bootstrap.min.css";

class Sidebar extends React.Component {
  state = {
    open: window.matchMedia("(min-width: 1024px)").matches || false
  };

  ontoggleNav = () => {
    this.setState(prevState => ({
      open: !prevState.open
    }));
  };

  render() {
    const { open } = this.state;
    const mobile = window.matchMedia("(max-width: 768px)").matches;
    console.log(mobile, open);
    return (
      <div>
        <div className="navHeaderWrap">
          <Header ontoggleNav={this.ontoggleNav} />
        </div>
        <div className="bodyWrap">
          <div className={classnames({ blur: mobile && open })} />
          <div
            className={classnames(
              "sidenav",
              { sidenavOpen: open },
              { sidenavClose: !open }
            )}
          >
            <a
              href="javascript:void(0)"
              className="closebtn hidex"
              onClick={() => this.ontoggleNav("0px")}
            >
              &times;
            </a>  
            <Link to="/Activities">Activities</Link>
            <Link to="/Transition">Transition</Link>
            <Link to="/Ticket">Ticket</Link>
          </div>

          <div
            className={classnames(
              "main",
              { mainShrink: open },
              { mainExpand: !open },
              { noscroll: mobile && open }
            )}
          >
            <h2> Push this Div inside</h2>
            <Outlet />
          </div>
        </div>
      </div>
    );
  }
}

export default Sidebar;
