import { PaginationTable } from './OrderTable';
import searchIcon from '../img/search.png';
import '../App.js'

function Customer(){
    return(

        <div style={{margin:'20px' }}>
            <div style={{display:'flex', justifyContent:'space-between',alignItems: 'center'}}>
                <h1>Customer Details</h1>
                <div style={{display:'flex'}}>
                    <div className='table-bottom'><button > + Add Cusstomer</button></div>                    
                    <div  className='search-input' style={{margin: '30px'}}>
                        <input type="text" placeholder="Search...." />
                    <img src={searchIcon} alt=':)' /></div> </div>  
            </div>
        <PaginationTable />
        </div>

    );
}

export default Customer;