import { PaginationTable } from './OrderTable';
import searchIcon from '../img/search.png';
import '../App.css'

function Transition(){
    return(

        <div style={{margin:'20px' }}>
            <div style={{display:'flex', justifyContent:'space-between',alignItems: 'center'}}>
                <h1>Transition</h1>
                <div className='search-input'>
                    <input type="text" placeholder="Search...." />
                    <img src={searchIcon} alt=':)' /></div>
            </div>
        <PaginationTable />
        </div>

    );
}

export default Transition;