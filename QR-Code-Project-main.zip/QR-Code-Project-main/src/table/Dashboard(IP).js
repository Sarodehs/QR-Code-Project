import Activities from './Activities';
import  RequestforService from './RequestForService';

function Dashboard(){
    return(
        <>
        <RequestforService />
        {/* <h1><a href=<Activities />Activities tract</a></h1>
       <h1><a href=''>Request for service</a></h1> */}
        </>
    )
}

export default Dashboard;