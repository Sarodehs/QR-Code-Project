import React, { useState } from 'react'
import data from './activiti-data'
// import './Activiti-list.css'


function ActivitiesList() {
  const [people, setPeople] = useState(data)
  return (
    <div>
    <main>
      <section className='person-container'>

      <article  className='person'>
            <img src='https://assets.webiconspng.com/uploads/2016/12/User-Icon-PNG.png' alt='avtar' />
            <div> <h4>Pankaj  Kunal</h4>  <p>03, Oct 21, 10:25 AM;</p>      </div>
            <div >Call for plan exiry reminder</div>
      </article>  
      <article  className='person'>
            <img src='https://assets.webiconspng.com/uploads/2016/12/User-Icon-PNG.png' alt='avtar' />
            <div> <h4>Pankaj  Kunal</h4>  <p>03, Oct 21, 10:25 AM;</p>      </div>
            <div >Call for plan exiry reminder</div>
      </article>      
      <article  className='person'>
            <img src='https://assets.webiconspng.com/uploads/2016/12/User-Icon-PNG.png' alt='avtar' />
            <div> <h4>Pankaj  Kunal</h4>  <p>03, Oct 21, 10:25 AM;</p>      </div>
            <div >Call for plan exiry reminder</div>
      </article>
     
      </section>
    </main>
    
    <div className='table-bottom' style={{justifyContent: 'end'}}>

    <button>      {'<<'}    </button>{' '}
    <button>  Previous    </button>{' '}
    <button >      Next    </button>{' '}
    <button>      {'>>'}    </button>{' '}

    {/* <button onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
      {'<<'}
    </button>{' '}
    <button onClick={() => previousPage()} disabled={!canPreviousPage}>
      Previous
    </button>{' '}
    <button onClick={() => nextPage()} disabled={!canNextPage}>
      Next
    </button>{' '} */}
    </div>

    </div>
    
  )
}



export default ActivitiesList;










{/* <section .className='container'>
<article key={id} className='person'>
      <img src={image} alt={name} />
      <div>
        <h4>{name}</h4>
        <p>{age} years</p>
      </div>
    </article>
</section> */}
