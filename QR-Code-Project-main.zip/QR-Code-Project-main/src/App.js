
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Sidebar from './Navigation/Sidebar';
import Dashboard from './table/Dashboard(IP)';
import Transition from './table/Transition';
import Ticket from './table/Ticket';
import Customer from './table/Customer';
import './App.css'


export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Sidebar />}>
          <Route index element={<Dashboard />} />
          <Route path="transition" element={<Transition />}  ></Route>
          <Route path="customer" element={<Customer />} />
          <Route path="ticket" element={<Ticket />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

