import { daysToWeeks } from "date-fns";
import logo from '../img/logo.png';
import Avatar from "@material-ui/core/Avatar";
import React from "react";
import {  Collapse,  Navbar,  NavbarToggler,  NavbarBrand,  Nav,  NavItem,  NavLink,  UncontrolledDropdown,
  DropdownToggle,  DropdownMenu,  DropdownItem} from "reactstrap";
import "./navigation.css";
export default class Example extends React.PureComponent {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      isOpen: false
    };
  }
  toggle() {
    this.setState({
      isOpen: !this.state.isOpen
    });
  }
  render() {
    const { ontoggleNav } = this.props;
    let d = new Date();
    let today =d.getDate() + '/ ' + d.getMonth() + '/ ' +d.getFullYear() ;

    return (
      <div>
        <Navbar color="light" light expand="md">
          <NavbarBrand>
           <img src={logo} alt="logo" width='60' /> 
          <span style={{color:'#ff7000'}}>{today}</span> &nbsp;
            <span className="hmbger" onClick={ontoggleNav}> 
              &#9776;
            </span>
            
          </NavbarBrand>
          <NavbarToggler onClick={this.toggle} />

          <Collapse style={{justifyContent: 'space-around'}} isOpen={this.state.isOpen} navbar>

              <Nav>
              <NavItem >                
              <NavLink href="#" >
                <UncontrolledDropdown nav inNavbar>
                <DropdownToggle nav caret style={{color:'black'}}>
                  Anand 2.0 
                </DropdownToggle>
                <DropdownMenu end>
                {/* <DropdownMenu right> */}
                  <DropdownItem>Option 1</DropdownItem>
                  <DropdownItem>Option 2</DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>Reset</DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown>
              </NavLink>
              </NavItem>
              </Nav>

              <Nav className="ml-auto" navbar>   

                <NavItem>
                  <NavLink href="#" style={{fontSize:'xx-large'}}>🕭 |</NavLink>
                </NavItem> 
                <NavItem style={{display:'flex',alignItems: 'end'}}>
                  <NavLink href="https://github.com/reactstrap/reactstrap" >
                  <Avatar   alt="Avatar"    src=''   />
                  </NavLink><p>Jayesh Saroed</p>
                </NavItem>
        
              </Nav>
            
          </Collapse>
        </Navbar>
      </div>
    );
  }
}
